from flask import Flask

app = Flask(__name__)

@app.route("/")
def welcome():
    return "Hello World"

@app.route("/home")
def home():
    return "Home Page"

if __name__ == "__main__":
    app.run(debug=True)
# import Contoller.user_controller as user_controller
# import Contoller.product_controller as product_controller
from Contoller import *

