from app import app
@app.route("/new")
def new():
    return "This is new page"