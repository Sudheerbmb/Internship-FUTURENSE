from app import app
@app.route("/product/add")
def padd():
    return "This is product up operation"